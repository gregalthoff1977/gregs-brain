Chronological record of ingests, queries, and maintenance passes.

## [2026-06-17] ingest | Current wiki inbox
- Updated page: [Inbox insights](inbox-insights.md)
- Processed inbox item: [Local ingest proof](inbox/2026-06-16-local-ingest-proof.md) by merging it into the existing inbox synthesis page.
- Processed inbox item: [Real workspace email test](inbox/2026-06-16-real-workspace-email-test.md) by merging it into the existing inbox synthesis page.
- Updated overview with the current inbox source count, page count, and findings.
- Key takeaway: the current inbox contains operational smoke-test emails, so one cited synthesis page is more useful than separate thin pages.