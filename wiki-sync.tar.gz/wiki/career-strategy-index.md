---
title: career-strategy-index
tags: [career]
---

# Career Strategy Index

Current career themes:

- **AI workflow builder**: Building practical AI-enabled systems, tools, and workflows that improve creative, product, and operational execution.
- **Design systems leader**: Leading scalable design systems, component strategy, governance, and cross-functional adoption.
- **Design director moving toward spirits/beverage**: Positioning design leadership experience toward brand, packaging, and experience work in spirits and beverage.
- **LinkedIn content strategy**: Developing a public thought-leadership stream around AI workflows, design leadership, systems thinking, and category transition.
