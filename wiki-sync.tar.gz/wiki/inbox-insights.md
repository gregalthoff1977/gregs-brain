---
title: Inbox insights
description: Evidence from inbox email smoke tests that verify API writes into the Gregs Brain wiki workspace.
date: 2026-06-17
tags:
- inbox
- insights
- email
---

Two current inbox items document email-to-wiki smoke tests rather than durable standalone topics. Both are better merged here as operational evidence about the ingest path, with links back to the original inbox entries: [Local ingest proof](inbox/2026-06-16-local-ingest-proof.md) and [Real workspace email test](inbox/2026-06-16-real-workspace-email-test.md).

## Processing Decisions

| Inbox item | Source | Decision | Rationale |
| --- | --- | --- | --- |
| [Local ingest proof](inbox/2026-06-16-local-ingest-proof.md) | `/wiki/inbox/2026-06-16-local-ingest-proof.md` | Merge into this page | The item is a minimal plain-text email proving API write capability, not a reusable standalone concept. |
| [Real workspace email test](inbox/2026-06-16-real-workspace-email-test.md) | `/wiki/inbox/2026-06-16-real-workspace-email-test.md` | Merge into this page | The item verifies the API path against the real MCP workspace and complements the first smoke test. |

## Evidence

- Source [Local ingest proof](inbox/2026-06-16-local-ingest-proof.md): came from `test@example.com`, used the subject `Local ingest proof`, and contained plain text rather than HTML.
- Source [Real workspace email test](inbox/2026-06-16-real-workspace-email-test.md): came from `real.sender@example.com`, used the subject `Real workspace email test`, and had HTML available but no plain-text body flag.
- Together, the two items show the email/API path can create wiki inbox pages in both a local proof case and the real MCP workspace case.

## Useful Idea

Use these inbox emails as lightweight smoke tests for future ingest changes: after modifying the email/API pipeline, replay a known minimal plain-text message and a real-workspace HTML-backed message, then verify that both create the expected `/wiki/inbox/` pages.

## Related

- The original inbox items now link back to this synthesis page for traceability.
- [Codex MCP Test](codex-mcp-test.md) records a separate MCP write check.
