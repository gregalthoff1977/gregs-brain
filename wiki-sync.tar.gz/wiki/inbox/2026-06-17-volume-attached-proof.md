---
title: Volume attached proof
tags:
- email
- inbox
source: email
email:
  sender: test@example.com
  subject: Volume attached proof
  received_at: '2026-06-17T02:00:00Z'
  has_body_html: false
  has_body_text: true
---

# Volume attached proof

This should write into the mounted Railway volume.
