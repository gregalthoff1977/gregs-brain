---
title: Real workspace email test
description: HTML-backed email smoke test created through the API against the real MCP workspace.
date: 2026-06-17
tags:
- email
- inbox
source: email
email:
  sender: real.sender@example.com
  subject: Real workspace email test
  received_at: '2026-06-16T21:30:00Z'
  has_body_html: true
  has_body_text: false
---

# Real workspace email test

This email was created through the API running against the real MCP workspace.

Search verification phrase: real workspace email test.

Processed in [Inbox insights](../inbox-insights.md).
