---
title: Local ingest proof
description: Plain-text email smoke test proving the API can write into Gregs Brain.
date: 2026-06-17
tags:
- email
- inbox
source: email
email:
  sender: test@example.com
  subject: Local ingest proof
  received_at: '2026-06-16T12:00:00Z'
  has_body_html: false
  has_body_text: true
---

# Local ingest proof

This proves the API can write into Gregs Brain.

Processed in [Inbox insights](../inbox-insights.md).
